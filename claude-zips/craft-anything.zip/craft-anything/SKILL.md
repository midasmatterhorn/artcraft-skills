---
name: craft-anything
description: "Craft Anything is ArtCraft's open-source, pure-Rust reverse-engineering and rebuilding workbench: it inspects a website, desktop/phone app, game or file (disassembler, decompiler, archives, browsers, databases, packet captures), has a coding agent rebuild it in your chosen stack, compares against the original at three widths or via self-tests, and refines until it matches. Trigger whenever the user mentions Craft Anything, craft-anything-cli, craft.json, .cany, its 303-tool engine, MCP server, Clean room vs Deep mode, per-project builder approvals or project layout — or describes the job (\"rebuild this website/app/game\", \"how does X work under the hood\", \"figure out how this site is built\", \"make a clone of this app\", \"disassemble this binary\"). Do not assume IDA Pro or Ghidra behaviour; read this first."
---

# Craft Anything

> **Full trigger scope:** Craft Anything is ArtCraft's open-source, pure-Rust reverse-engineering and rebuilding workbench: point it at a website, desktop app, phone app, game or file, and it studies the original with real inspection tools (disassembler, decompiler, archives, browsers, databases, packet captures), has a coding agent (Claude Code first) build a new project in the stack you name, compares the result against the original at three screen widths or via the built program's own self-test, and refines until it matches. Trigger this skill whenever the user mentions Craft Anything (or `craft-anything-cli`, `craft.json`, `.cany`, "rebuild this website/app/game", "how does X work under the hood"), asks to inspect or reverse-engineer software they own, wants an agent-driven study→build→check pipeline, asks about its 303-tool engine, its MCP server, Clean room vs Deep mode, per-project builder approvals, or its project folder layout — and equally when they never name it but describe the job ("figure out how this site is built", "make me a clone of this app", "disassemble this binary and tell me what it does"). Do not assume Ida-Pro-style or Ghidra-style behaviour: read this first.

**Audit basis.** Refreshed 2026-11-12 against tag **v0.6.1**, commit **`48a9c5a60ff83ff620f98661339be6281a7debc6`** — `git rev-parse HEAD` in the pinned checkout confirms, and the installed bundle matches (`Info.plist` `CFBundleShortVersionString` 0.6.1, bundle id `ai.storyteller.craft-anything`; its bundled `craft-anything-cli --version` prints `craft-anything-cli 0.6.1`). The previous release this skill described was v0.5.0 (`622d023cdfdb91c00df8b9a37c486a2a18fb0917`).

**v0.5.0 → v0.6.1 delta.** 499 files changed (+51,694/−3,455). Engine tools 301 → **303** in the same 17 toolsets: `core` 35 → 36 (`core_text_read` reads a text source as paged text — 64 MiB cap, 200 lines a page, 2,000 max) and `projects` 20 → 21 (`project_approvals_set`), with `MIN_TOOLS` still 271 (`docs/tools.md`; `crates/engine/src/tool_list.rs`). Projects now carry the person's **approval policy** for seven builder action kinds — `web`, `commands`, `outside_files`, `publish`, `delete_outside`, `system`, `other_tools` — each allow / ask / refuse or unset: Auto mode allows web, commands and outside files and refuses the other four; with Auto off everything but web asks, and an agent's own call can only tighten it (`crates/engine/src/workspace.rs` `ACTION_KINDS`; `crates/engine/src/tools/project_tools.rs`; `docs/claude-code.md`). `craft.json` went 2 → **5** (`approvals`, `agent_session_deep`, `capture_deep`), `inbox/build-progress.json` 1 → **2** (`checked`: a fully passing check round kept while nothing it looked at changes) and `transcript.json` 1 → **2** (`deep`; a transcript without it resumes only in Deep) (`docs/file-formats.md`; `crates/ai/src/rebuild/kept_check.rs`). Coding agents: built-in adapters 9 → **12** (Aider, Grok Build, Devin; 9 adapter modules) and the known-CLI list 11 → **14**; a grants table now states which builder gets our tool server and approvals — Claude Code, Copilot (ACP) and Grok (ACP) get both, Codex, OpenCode and DeepSeek Harness get the server without our approvals, Devin gets both only over ACP, and Gemini CLI, Antigravity, Hermes, Maki and Aider get neither (`crates/ai/src/cli_agents/adapters.rs`; `crates/ai/src/cli_agents/grants.rs`). Deep Claude Code builders may start subagents; Clean room does not (`docs/claude-code.md`). The macOS app finds a Codex CLI bundled inside ChatGPT.app/Codex.app after PATH, Settings → AI checks each agent CLI without sending a prompt, and `requests_per_minute` paces an API backend (`docs/codex.md`; `crates/ai/src/pace.rs`). UI languages 15 → **17** (ไทย, Eesti) (`crates/ui-egui/src/i18n.rs`). CLI named subcommands stay 12 and `commands` prints **323** (303 engine + 20 AI/setup). `rebuild` flags are unchanged, but a folder that already holds a project now treats the request as a follow-up and refuses `--existing`, `--build-with` and `--generate-assets` (`apps/craft-anything-cli/src/rebuild_cmd.rs`).

**v0.3.0 → v0.5.0 delta.** 481 files changed. Engine tools 299 → **301** in the same 17 toolsets: `core` 34 → 35 (`core_finding_edit`) and `projects` 19 → 20 (`project_plan_fold`), with `MIN_TOOLS` still 271 (`docs/tools.md`; `crates/engine/src/tool_list.rs`). The installed `craft-anything-cli commands` listed **321** commands — the 20 AI/setup-layer tools on top (`rebuild_*`, `assets_key_*`, `ai_model*`, `setup_*`) — so 321 was not the engine count. MCP gained a shared-host mode: `mcp --restricted` drops and refuses machine-acting and network tools, `--allow-web` / `--allow-capture` re-enable those classes, and `--target` passes desktop target metadata (`apps/craft-anything-cli/src/main.rs`; `crates/mcp/src/lib.rs`). Coding-agent adapter modules went 3 → 6 — `copilot`, `dsh` (DeepSeek Harness) and `maki` joined `antigravity`, `hermes` and `opencode` — while the built-in registry held 9, because Claude Code, Codex, Gemini CLI and OpenCode are registered without a module file (`crates/ai/src/cli_agents/adapters.rs`; `docs/copilot.md`, `docs/opencode.md`); Claude Code remained the first-class builder, and only Maki among the ACP agents had been run live then. New projects in Python, Go, .NET, Maven, Gradle and Make now build, test and launch through the same catalogue as Rust and Node.js (`crates/engine/src/toolchains.toml`, 8 toolchains; `docs/STATUS.md`). UI languages 5 → 15 (`crates/ui-egui/src/i18n.rs` `LANGUAGES`, `crates/ui-egui/src/i18n/*.tsv`). Versioned files grew to 12 rows with `inbox/build-progress.json`, `pin.json` version 2 and `feed.json` version 5 (`docs/file-formats.md`; `crates/engine/src/workspace/progress.rs`, `crates/engine/src/pins.rs`, `crates/engine/src/feed.rs`). Public installers are published, and the README states that Clean room is not an OS sandbox and that dependency installs run code.

**v0.2.0 → v0.3.0 delta.** 135 files changed. Engine tools 298 → **299** (the `projects` toolset 18 → 19). The macOS bundle **does** ship `craft-anything-cli` — the earlier skill said it did not, and `packaging/macos/package.sh` copies, signs and version-checks it. CLI: `--build-with` and `--generate-assets` added, `--resume` requires `--continue-in` and ignores the request, `--rounds` defaults to 2. Repo docs are stale against the generated `docs/tools.md` (README said 314/298 at that tag).

**Verify against your installed version** — the ArtCraft Launcher auto-updates, so a newer build may differ; every count quoted here was re-measured at this tag, and code paths that moved were re-cited. The measurement method for each count is in `evidence.md`.

## Overview

Craft Anything is "See how any website, app or game works, then have AI build your own version" — an open-source, clean-room engine in pure Rust by the ArtCraft/storytold project (`README.md`, MIT OR Apache-2.0). It works in four steps — **Study → Build → Check → Ready** — asking the person question/approval cards when a decision is theirs, and at v0.6.1 each project can set per-kind builder approvals (`README.md` "How it works"; `crates/engine/src/workspace.rs` `ACTION_KINDS`). Two UI modes drive the same engine: **Simple** (a project page with the four steps) and the **Advanced** workbench (functions, pseudo-C, disassembly, hex, call graphs, evidence ledger, agent console). **Clean room** (default) inspects only what a visitor can see — screenshots, visible text, measured layout, colours, fonts — and refuses look-inside tools; **Deep** reads code and files with the built-in engines and Ghidra when installed (`README.md` "Clean room or Deep"; `crates/engine/src/tools/deep.rs`). Building needs a coding agent signed in on your machine — **Claude Code** is supported first (your own unmodified `claude`, your own sign-in); Codex, Copilot, Grok Build, OpenCode, DeepSeek Harness, Aider, Devin and other ACP agents are built, and README says Maki and Devin have been run live (`README.md` "AI"; `docs/grok.md`, `docs/codex.md`). **Status: early alpha** — website rebuilds with three-width checks and game rebuilds in Unity/Unreal/Godot work today; app/game behaviour checks are partial; some engine tools are tested only against stand-ins (`README.md` Status; `docs/STATUS.md`; `docs/tool-status.md`). Source: GitHub `storytold/craft-anything`.

## Capabilities (verified)

### One tool registry, three surfaces

- **303 engine tools in 17 toolsets** at this tag, generated into `docs/tools.md` by `cargo xtask tools` and kept honest by a test floor (`MIN_TOOLS = 271`, unchanged at v0.6.1; `crates/engine/src/tool_list.rs:7`). Each tool is simultaneously an **MCP tool**, a **CLI command** (`craft-anything-cli <id with dashes>`) and a callable tool for the coding agent; the AI and setup layers add 20 more on top (`rebuild_*` 9, `assets_key_*` 3, `ai_model*` 4, `setup_*` 4), so `craft-anything-cli commands` prints **323**, not 303. Toolsets: `core` 36, `native` 55, `apple` 14, `formats` 36, `managed` (.NET) 8, `android` 14, `java` 6, `adb` 24, `browser` 22, `javascript` 11, `runtime` 14, `frida` 9, `application` 17, `database` 1, `projects` 21, `setup` 9, `build` 6 (`docs/tools.md`). The README's "320 tools (300 in the engine)" and `docs/STATUS.md`'s "300 engine tools (320 with the AI and setup layers')" are both stale — quote 303/323.
- **Results are evidence, not answers**: every result carries confidence, coverage and limitations; big ones come back as a summary and page with `core_evidence_browse`. The discipline rules (predict-then-check, cite evidence ids, absence is not proof) are appended to every guided prompt (`crates/mcp/src/prompts.rs` `DISCIPLINE`).
- **MCP server** (`craft-anything-cli mcp`): stdio JSON-RPC; tools default to Essentials plus enabled toolsets, `--all-tools` lists everything; `--inbox DIR` posts `core_person_ask`/`core_action_approve` cards for the desktop app to answer; `--target <json>` takes desktop target metadata (`apps/craft-anything-cli/src/main.rs` `Mcp`). The list is **filtered by mode**: measured against the installed bundle, Deep `--all-tools` lists **323** tools (303 + the 20 extras) while Clean room `--all-tools` lists **108** — exactly the ids in `crates/engine/src/clean_room.rs` `TOOLS` (`crates/mcp/src/lib.rs` `listed`). On a shared host use **`--restricted`**: it omits and refuses tools that act on the machine or reach the network, with `--allow-web` and `--allow-capture` to turn those classes back on (`crates/mcp/src/lib.rs` `restricted_refusal`). **6 guided prompts**, unchanged at v0.6.1 and confirmed live over `prompts/list` (`crates/mcp/src/prompts.rs` `PROMPTS`).
- **CLI subcommands** (`apps/craft-anything-cli/src/main.rs` `Command`): **12 named** — `mcp`, `setup`, `doctor`, `uninstall`, `commands`, `capabilities`, `triage <path>`, `report [--html] [--out] [--no-evidence]`, `chat`, `rebuild`, `ai`, and the hidden `builder-notes` hook (`--help` shows the first 11) — plus **`Tool(Vec<String>)` pass-through** so every tool id is a subcommand (`core-text-read`, `project-approvals-set`, …). The 12 named subcommands are unchanged at v0.6.1; unknown flags are refused.
- **Rebuild from the terminal** (questions asked in the terminal): `craft-anything-cli rebuild <target|"-" for none> "<request>"` with `--rounds N` (default 2), `--backend`, `--unattended`, `--projects-dir`, `--project-folder` + `--existing edit|start-from`, `--continue-in` + `--resume`, `--deep` / `--clean-room`, `--build-with`, `--generate-assets` (`apps/craft-anything-cli/src/rebuild_cmd.rs`). The flag set is unchanged at v0.6.1, but a `--project-folder` that already holds a project keeps its saved target, settings and stack and treats the request as a follow-up; `--existing`, `--build-with` and `--generate-assets` are refused there (use `--continue-in` or `project-assets-allow` later).

### Study (the inspection engine)

- Its own pure-Rust **decoders, disassembler and decompiler** work without outside programs; Deep mode additionally uses **Ghidra** when installed (`README.md` "Under the hood"). Native programs (ELF/Mach-O/PE), .NET (incl. IL2CPP, bundles), Java (with decompilation), Android (adb, APK/AXML/ARSC signing), Apple (runtime, codesign, CAR), Electron (asar, fuse, runtime), JavaScript/JS bundles, websites (CDP browser automation), firmware, packet captures, databases, game archives — one toolset each (`crates/engine/src/tools/`, `crates/formats/src/`). 217 files under `crates/formats/` changed at this tag (archive/extent hardening, new Unity R16/RG16/RGB9e5 and Unreal float texture decoding; `crates/formats/src/unity_texture.rs`, `crates/formats/src/unreal_texture.rs`; `docs/STATUS.md`).
- **Text sources** are readable outside a build: `core_text_read` takes an absolute path or the active target, reads UTF-8 and BOM'd UTF-16, pages by lines (default 200, max 2,000, 256 KiB a page, 64 MiB a file), counts invalid bytes as U+FFFD, refuses a file with a zero byte in its first 8 KiB as binary, and runs nothing (`crates/engine/src/tools/text_tools.rs`). It is Deep-only because it carries target content.
- External engines are optional and detected: Ghidra, Cutter, rizin, GDB, Frida, adb, jadx, JEB, tshark, apktool and CDP browsers (`crates/engines/src/`; `engines_*` tools in `docs/tools.md`); `craft-anything-cli doctor` checks the install, registrations, engines, AI backends and the MCP server.
- "Just look inside" opens a target for questions without building anything (Deep mode).

### Build, check, refine

- The builder is **your own Claude Code** (first-class). Codex, Copilot (ACP), Grok Build (ACP), OpenCode, DeepSeek Harness, Aider, Devin and plain ACP agents are switchable per backend; **which builder gets the tool server and the approval policy is declared per adapter**, not assumed (`crates/ai/src/cli_agents/grants.rs`): Claude Code, Copilot and Grok get both, Codex and OpenCode get the server without our approvals, DeepSeek Harness gets the server but no checked approval path, Devin gets both only over ACP, and Gemini CLI, Antigravity, Hermes, Maki and Aider get neither. README says only Maki and Devin among the ACP agents have been run live; Codex is still unverified (`README.md` "AI"; `docs/copilot.md`, `docs/opencode.md`, `docs/grok.md`). Craft Anything never sees your account; generated pictures and 3D models are opt-in with your own fal.ai key.
- **Per-project approvals**: seven action kinds, each allow / ask / refuse; unset follows Auto mode (Auto: allow web, commands, outside files; refuse publish, deletes outside, system, other tools. Auto off: ask for all but web). The person loosens from the app or CLI; an agent's `project_approvals_set` may only make a kind stricter (`crates/engine/src/workspace.rs` `ACTION_KINDS`, `Manifest::approval`; `crates/engine/src/tools/project_tools.rs`).
- **Checks**: websites are compared at three screen widths; games run the generated program's own `--self-test` against `checks/round-N/self-test.json`; app runs are compared; each round writes into `checks/` and the agent refines what doesn't match (`README.md` Status; `crates/engine/src/self_test.rs`; `docs/file-formats.md`). A round in which every check passed is kept in `inbox/build-progress.json` (`checked`) and stands while nothing it looked at changes, so a prompt that changes nothing in `app/` does not rebuild and restart (`crates/ai/src/rebuild/kept_check.rs`).
- New projects in Python, Go, .NET, Maven, Gradle and Make are built, tested and launched from one catalogue (`crates/engine/src/toolchains.toml` — 8 toolchains with Rust and Node.js; unchanged at v0.6.1).
- **Plugins**: MCP servers, and WASM components in builds with the `wasm-plugins` option (`crates/engine/src/plugins.rs`; `crates/engines/src/wasm_plugin.rs`).

### Project folder and file formats (all versioned, migration steps on open)

- New projects go to `Documents/Craft Anything` (Settings → General) unless `--project-folder`. Layout: `craft.json` (request, target, status, history, approvals), `capture/`, `app/` (the generated project), `checks/`, `investigation.cany/` (evidence ledger), `inbox/` (open questions and `build-progress.json`) (`README.md` "Get started").
- Version constants in code: `craft.json` `MANIFEST_VERSION` **5** (`crates/engine/src/workspace.rs:83`), `config.toml` `SETTINGS_VERSION` **3** (`crates/engine/src/settings.rs:222`), `investigation.cany/project.toml` `FORMAT_VERSION` **1** (`crates/engine/src/project.rs:22`), `transcript.json` **2** (`crates/ai/src/context.rs:22`), `inbox/build-progress.json` **2** (`crates/engine/src/workspace/progress.rs:21`), `pin.json` **2** (`crates/engine/src/pins.rs:37`), `feed.json` **5** (`crates/engine/src/feed.rs:19`). `docs/file-formats.md` still has **12 rows**; manifest, settings, `project.toml`, build-progress and pin each assert one migration step per version at compile time, while `transcript.json` and `feed.json` migrate by field and shape. ⚠️ **Repo-doc drift:** the same table's `config.toml` row still says `SETTINGS_VERSION` = 2 while the code says 3 — trust the code constant (`docs/file-formats.md:12`).
- **Mode is recorded with the work**: `craft.json` gained `agent_session_deep` (a saved builder session's mode) and `capture_deep` (the current `capture/`'s mode); a version-3 session and a version-4 capture migrate as Deep. `transcript.json` gained `deep`, and a transcript without it is resumed only in Deep. A capture studied in one mode is not handed to a build in the other — the run studies again. `craft.json` also keeps `decompiled` (the builder has read the original's code in this project) so a Deep run doesn't repeat the reminder after every request (`crates/engine/src/workspace.rs` `manifest_v3_to_v4`/`manifest_v4_to_v5`, `decompiled`; `crates/ai/src/rebuild/study.rs`).
- Newer files are never downgraded or overwritten: `craft.json` opens read-only (saving refused), `project.toml` is refused with "update Craft Anything", `build-progress.json` stops the build and leaves the record unchanged.

### AI backends and coding agents

- **Anthropic, OpenAI, OpenRouter, xAI (Grok, when `XAI_API_KEY` is set) and local OpenAI-compatible servers** are available for questions and analysis (Settings → AI; `README.md` "AI"). Backends can be paced with `requests_per_minute` so every conversation on a backend shares one request budget (`crates/ai/src/pace.rs`; `crates/ai/src/config.rs`).
- **Coding-agent CLI management**: `ai list|detect|add|remove|key|on|off|program|folder|model|effort|test|builder|extractor`. `ai add --acp` turns on ACP for an `agent_cli` backend, `ai key --forget` drops a saved key, and `ai test` checks a backend and reports its result and latency (for an agent CLI that is a version/sign-in check, not a prompt) (`apps/craft-anything-cli/src/ai_cmd.rs`). Settings → AI's **Check** runs an agent's `--version` (and sign-in status where the adapter can tell) on a worker without sending a prompt; a macOS Dock launch also finds a Codex CLI inside ChatGPT.app/Codex.app after PATH (`docs/codex.md`; `docs/STATUS.md`). Grok Build is a build backend only: chats and questions are refused (`docs/grok.md`).

## Known limitations and not-implemented

Do not assign these at v0.6.1:

- **Only Claude Code is the first-class, verified builder.** Codex, Copilot, Grok Build and the other ACP adapters are built; README says only Maki and Devin among the ACP agents have been run live, and Codex hasn't been verified on a real install (`README.md` "AI", "Status").
- **Approvals are a bar, not a wall.** They decide what the builder may do without asking; a builder allowed to run commands runs with the person's own permissions and could change project records another way. `commands: allow` is Auto mode's default and trusts the builder (`docs/claude-code.md`).
- **An agent cannot loosen approvals**: `project_approvals_set` from MCP or an agent may only make a kind stricter; changing it the other way is the person's job in the app or CLI (`crates/engine/src/tools/project_tools.rs`; `crates/engine/src/tool.rs` `AGENT_ENV`).
- **Not every builder gets the same powers.** Gemini CLI, Antigravity, Hermes, Maki and Aider get neither our tool server nor our approvals; Codex, OpenCode and DeepSeek Harness get the server without our approval decisions; Devin only over ACP (`crates/ai/src/cli_agents/grants.rs`).
- **Grok Build is a build backend only**: chats and questions are refused; the xAI API backend (when `XAI_API_KEY` is set) is separate (`docs/grok.md`).
- **Behaviour checks for apps and games are partial**; website checks are the mature path.
- **Some engine tools are tested only against stand-ins** (`crates/engine/src/tools/standin_tools.rs`; `docs/tool-status.md` marks each tool; `core_text_read` is listed there as new and unit-tested, not part of the 2026-10-16 functional audit).
- **Clean room is not an OS sandbox**: it is a rule about which tools Craft Anything offers and refuses. A coding agent you run still acts as you, with its own permissions (`README.md` "Clean room or Deep").
- **Clean room offers only 108 tools** (measured over MCP); expecting the other 195 is a mode error, not a missing install.
- **Installing dependencies runs code**: npm install scripts, Rust build scripts and Python source packages execute on your machine. Craft Anything asks before a command kind it has not seen in the project; "always allow" then covers every later command of that kind, so grant it only for trusted dependencies (`README.md` "Responsible use").
- **`core_text_read` is not a parser**: it refuses a file with a zero byte in its first 8 KiB, cuts lines over 256 KiB, caps at 64 MiB, and runs nothing; use `core_target_triage` or the native tools for binaries (`crates/engine/src/tools/text_tools.rs`).
- The managed tier is still "next"; the browser build is a viewer, not the full workbench (`apps/craft-anything-web`; `README.md` Status).
- It **never bypasses DRM, logins or anti-cheat**, and the builder is told not to copy logos/photos/text without confirmation of ownership — respect that when writing requests (`README.md` "Responsible use").

## How to operate

- GUI: `open -a "Craft Anything"`; the app binary is `Contents/MacOS/craft-anything`. Do not launch the GUI just to run a CLI command — see *Getting the CLI* below for where `craft-anything-cli` lives and how to install it.
- Mode: switch Clean room/Deep in the title bar or Settings, `craft-anything-cli settings-set --key deep_mode --value true`, or `--deep`/`--clean-room` per CLI run.
- Typical agent flow:
  ```sh
  craft-anything-cli doctor                      # what's missing (agents, engines, AI)
  craft-anything-cli capabilities                # toolsets, availability, engines
  craft-anything-cli triage ./target.bin         # first look, evidence records
  craft-anything-cli rebuild https://example.com "Recreate this website" --rounds 2
  craft-anything-cli rebuild - "A snake game in Rust"
  craft-anything-cli rebuild https://example.com "Make the header blue" --continue-in "<folder>"
  craft-anything-cli report --out report.md      # readable report from the ledger
  ```
- Approvals for one project (the tool's `--project` is the project folder, not the CLI's global evidence project):
  ```sh
  craft-anything-cli project-approvals-set --project "<project folder>"
  craft-anything-cli project-approvals-set --project "<project folder>" --kind publish --mode refuse
  ```
- Read a source text without a build: `craft-anything-cli core-text-read --path "<absolute path to notes.md>" --offset 0 --limit 200`.
- Serve the tools: `craft-anything-cli mcp --all-tools` (all 323 in Deep) or `craft-anything-cli mcp --restricted --inbox "<folder>"` on a shared host. A Clean room server can list only the 108 Clean-room tools, whatever `--all-tools` says. The global `--allow-run` skips the consent prompt for tools that run code or change a device — use it only on a target you own.
- Settings live in `config.toml` (`engine::settings::config_dir()`, version 3); `craft-anything-cli doctor` output is the live answer for paths and installed engines.

### Getting the CLI (the launcher installs the app, not the CLI)

The ArtCraft Launcher installs `Craft Anything.app`; it does not put `craft-anything-cli` on your
`PATH`. It **does** ship a copy inside the bundle at
`/Applications/Craft Anything.app/Contents/MacOS/craft-anything-cli`, the same build as the app, so
a launcher install can use that binary directly. The CLI is published on the app's GitHub release,
`craft-anything-cli-0.6.1-macos-universal.zip` (27.9 MB), so `craft-anything-cli` answering
*command not found* means "not installed yet", not "not supported".

Find it, in this order:

1. **On `PATH`** — `command -v craft-anything-cli`. If it answers, `craft-anything-cli --version`
   must report the version this skill was written against (0.6.1). A different version means the CLI
   and the app have drifted: re-read *Verify against your installed version* before trusting ids.
2. **Bundle copy** — `"/Applications/Craft Anything.app/Contents/MacOS/craft-anything-cli"
   --version`; to make it callable as `craft-anything-cli`, link it: `mkdir -p ~/.local/bin && ln -sf
   "/Applications/Craft Anything.app/Contents/MacOS/craft-anything-cli"
   ~/.local/bin/craft-anything-cli`.
3. **Install it from the release** — user-local, no `sudo`:

```sh
APP_VER=0.6.1
REL="https://github.com/storytold/craft-anything/releases/download/v$APP_VER"
ASSET="craft-anything-cli-$APP_VER-macos-universal.zip"
mkdir -p "$HOME/.local/bin" "$HOME/Downloads/craft-anything-cli" && cd "$HOME/Downloads/craft-anything-cli"
curl -fLO "$REL/$ASSET" && curl -fLO "$REL/SHA256SUMS.txt"
expected=$(grep -F "$ASSET" SHA256SUMS.txt | awk '{print $1}')
actual=$(shasum -a 256 "$ASSET" | awk '{print $1}')
[ "$expected" = "$actual" ] && echo "checksum OK" || { echo "checksum MISMATCH — stop"; exit 1; }
unzip -oq "$ASSET"
install -m 0755 "craft-anything-cli-$APP_VER-macos-universal/craft-anything-cli" "$HOME/.local/bin/craft-anything-cli"
"$HOME/.local/bin/craft-anything-cli" --version
```

`~/.local/bin` must be on `PATH` for the shell that runs the skill:
`export PATH="$HOME/.local/bin:$PATH"` (put it in your shell profile to keep it).

Rules: never `sudo` into `/usr/local`, never unzip into `/Applications`, and never replace an
existing `craft-anything-cli` of a different version without telling the user. Building from source
(`cargo install --path apps/craft-anything-cli --locked`) is a developer path only — full Rust
toolchain, minutes of compiling; prefer the release binary above. Prefer the bundle copy (step 2) —
it is the same commit as the app; a downloaded CLI is only needed on a machine without the app.

## Working with an AI agent

- **You are also the builder Craft Anything drives.** When its coding-agent bridge launches you, read the inbox/notes flow: the person's answers arrive via the `builder-notes` hook; approval-required actions go through `core_action_approve` rather than being assumed. Your CLI calls inherit `CRAFT_ANYTHING_AGENT`, so they are treated as an agent's: they cannot loosen a project's approvals (`crates/engine/src/tool.rs` `AGENT_ENV`; `apps/craft-anything-cli/src/main.rs` `caller`).
- **Study first, honestly**: keep the investigation memory current (`core_investigation_show`, `core_brief_write`, `core_plan_update`, `core_hypothesis_record`, `core_finding_record`, `core_handoff_write`) — the MCP prompts enforce this discipline and it makes your answers auditable. The embedded skill `setup` installs says the same (`crates/setup/src/skill.md`, version 2).
- **Respect the mode.** In Clean room the look-inside tools are absent from the list and refused with `details.reason` `clean_room`; don't try to work around them. A capture or transcript made in one mode is not resumed in the other; switching to Deep is the person's decision.
- **Prepare inputs** in formats the toolsets open (archives, binaries, captures, DB dumps); use `core_archive_extract` rather than shelling out, so evidence lands in the ledger. For plain source text, `core_text_read` keeps pages, offsets and counting in the evidence record.
- **Verify rebuilds** from `checks/` outputs and the per-round comparison reports; a "Ready" step is a claim — open the result and re-check before telling the person it matches. A kept check round (`progress.checked`) means nothing it looked at changed, not that you looked again.
- **Don't run `setup --yes` (or `setup --client …`) over an entry that already lists every tool**: `setup` writes the plain `mcp` command and silently drops an existing `--all-tools`, leaving the core toolset. Read the client's config first; `setup --dry-run` is safe and changes nothing (`crates/setup/src/plan.rs` `default_command`; `crates/setup/src/skill.md`).
- **What not to attempt:** bypassing DRM/logins/anti-tamper (refused by design), promising Codex/Copilot/Grok builds, editing `craft.json`/`.cany` by hand while a run is active, quoting the README's 320-tool number, assuming Ghidra is present (check `doctor`), serving MCP to a shared host without `--restricted`, or loosening approvals from an agent.

## Verification protocol

1. **Round-trip on a throwaway target first**: rebuild a tiny known website with `--rounds 1`, then read `craft.json`, `checks/round-1/` and `app/` before real work.
2. **Cite evidence ids** for every claim about the original; absence is not proof.
3. **Version your project folders** (copy the whole folder; every file carries a version and a newer file refuses saves).
4. **One project per run**: never edit a project folder while a rebuild is active; `--resume` exists for continuation.
5. **Check the kept round before trusting a pass**: `inbox/build-progress.json` `checked` only says the last fully passing round's inputs are unchanged; a failure is never kept, so "Try again" must look again (`crates/ai/src/rebuild/kept_check.rs`).
6. **Update between projects**: this skill is pinned to v0.6.1; re-run `doctor` after updates, and re-measure counts rather than trusting old prose.

## Sources & evidence

- Repo: https://github.com/storytold/craft-anything — inspected at tag **v0.6.1**, commit `48a9c5a60ff83ff620f98661339be6281a7debc6` ("Merge tested main for v0.6.1", 2026-11-11), inspection date **2026-11-12**; the previous tag v0.5.0 (`622d023cdfdb91c00df8b9a37c486a2a18fb0917`) was diffed against it for the delta. Apache-2.0 and MIT (`LICENSE-APACHE`/`LICENSE-MIT`).
- Installed `/Applications/Craft Anything.app`: `CFBundleShortVersionString` 0.6.1, `CFBundleIdentifier` `ai.storyteller.craft-anything`; the bundled `craft-anything-cli --version` prints `craft-anything-cli 0.6.1`. The GUI was never launched and the app binary was not executed.
- Read: `README.md`, `Cargo.toml`, `docs/{tools,tool-status,STATUS,file-formats,claude-code,codex,grok,copilot,opencode,localization}.md`, `docs/schemas/{craft,build-progress}.schema.json`, `apps/craft-anything-cli/src/{main,rebuild_cmd,ai_cmd}.rs`, `crates/engine/src/{tool_list,clean_room,workspace,settings,project,pins,feed,tool,lib}.rs`, `crates/engine/src/workspace/progress.rs`, `crates/engine/src/toolchains.toml`, `crates/engine/src/tools/{project_tools,interaction_tools,text_tools,deep,standin_tools}.rs`, `crates/mcp/src/{lib,prompts}.rs`, `crates/ai/src/{context,pace,config}.rs`, `crates/ai/src/rebuild/{kept_check,study}.rs`, `crates/ai/src/cli_agents/{adapters,grants,mod}.rs` and its adapter modules, `crates/setup/src/{plan,clients}.rs`, `crates/setup/src/skill.md`, `crates/ui-egui/src/i18n.rs`.
- Counts recomputed from source at v0.6.1: **303 engine tools in 17 toolsets** (`docs/tools.md` generated list; `MIN_TOOLS = 271`), **323 `commands` entries** (303 + 20 AI/setup extras), **323 MCP tools in Deep `--all-tools`** and **108 in Clean room** (live `tools/list` against the installed bundle; 108 = `clean_room::TOOLS`), **6 MCP prompts** (live `prompts/list`), **12 named CLI subcommands** (11 shown + hidden `builder-notes`) + external pass-through, **12 versioned-file rows**, **17 UI languages**, **8 toolchains**, **12 built-in coding-agent adapters** (9 adapter modules; 14 known agent CLIs), **7 approval kinds**, **13 crates + 3 apps** (unchanged at v0.6.1); version constants from code: manifest 5, settings 3, `.cany` 1, transcript 2, build-progress 2, pin 2, feed 5 (⚠️ `docs/file-formats.md`'s settings row still shows 2 — stale repo doc).
- Evidence table: `evidence.md` next to this file.
